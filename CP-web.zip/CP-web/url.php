<?php

	$host_ip = $_SERVER['HTTP_HOST'];

	$url = "http://".$host_ip."/cp-web/";

	$url_index.php = $url."index.php";

?>